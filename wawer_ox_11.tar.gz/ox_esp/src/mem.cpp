#include "mem.h"
#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <sys/uio.h>
#include <unistd.h>

static std::string read_file(const std::string& p, size_t cap = 4096) {
    std::string s;
    int fd = open(p.c_str(), O_RDONLY);
    if (fd < 0) return s;
    char buf[4096];
    ssize_t k;
    while (s.size() < cap && (k = ::read(fd, buf, sizeof buf)) > 0) s.append(buf, (size_t)k);
    close(fd);
    return s;
}

int Proc::find_pid(const std::string& needle) {
    std::string nd = needle;
    for (auto& c : nd) c = (char)tolower((unsigned char)c);
    DIR* d = opendir("/proc");
    if (!d) return 0;
    int found = 0;
    while (dirent* e = readdir(d)) {
        int p = atoi(e->d_name);
        if (p <= 1 || p == getpid()) continue;
        std::string cmd = read_file("/proc/" + std::to_string(p) + "/cmdline", 512);
        cmd = cmd.substr(0, cmd.find('\0'));                  // argv[0] only
        if (cmd.empty() || cmd.find(':') != std::string::npos) continue;   // skip pkg:service children
        for (auto& c : cmd) c = (char)tolower((unsigned char)c);
        if (cmd.find(nd) != std::string::npos) { found = p; break; }
    }
    closedir(d);
    return found;
}

bool Proc::attach(int p) {
    detach();
    pid = p;
    memfd_ = open(("/proc/" + std::to_string(p) + "/mem").c_str(), O_RDWR);
    if (memfd_ < 0) memfd_ = open(("/proc/" + std::to_string(p) + "/mem").c_str(), O_RDONLY);
    use_fd_ = false;
    return true;
}

void Proc::detach() {
    if (memfd_ >= 0) close(memfd_);
    memfd_ = -1; pid = 0;
}

bool Proc::alive() const { return pid > 0 && access(("/proc/" + std::to_string(pid)).c_str(), F_OK) == 0; }

bool Proc::read(uint64_t addr, void* out, size_t n) {
    if (!n) return true;
    addr = untag(addr);
    if (addr < 0x10000) { memset(out, 0, n); return false; }
    if (!use_fd_) {
        iovec l{out, n}, r{(void*)addr, n};
        ssize_t k = process_vm_readv(pid, &l, 1, &r, 1, 0);
        if (k == (ssize_t)n) return true;
        if (k < 0 && (errno == ENOSYS || errno == EPERM)) use_fd_ = true;   // blocked by seccomp/selinux -> /proc/pid/mem
        else { memset(out, 0, n); return false; }
    }
    if (memfd_ >= 0 && pread64(memfd_, out, n, (off64_t)addr) == (ssize_t)n) return true;
    memset(out, 0, n);
    return false;
}

bool Proc::write(uint64_t addr, const void* in, size_t n) {
    addr = untag(addr);
    if (!n || addr < 0x10000) return false;
    iovec l{(void*)in, n}, r{(void*)addr, n};
    if (process_vm_writev(pid, &l, 1, &r, 1, 0) == (ssize_t)n) return true;
    return memfd_ >= 0 && pwrite64(memfd_, in, n, (off64_t)addr) == (ssize_t)n;      // read-only mappings / blocked syscall
}

std::vector<Region> Proc::regions() {
    std::vector<Region> v;
    std::string s = read_file("/proc/" + std::to_string(pid) + "/maps", 1 << 24);
    size_t i = 0;
    while (i < s.size()) {
        size_t e = s.find('\n', i);
        if (e == std::string::npos) e = s.size();
        std::string line = s.substr(i, e - i);
        i = e + 1;
        unsigned long long a, b, off;
        char perm[8] = {0};
        int n = 0;
        if (sscanf(line.c_str(), "%llx-%llx %7s %llx %*s %*s %n", &a, &b, perm, &off, &n) < 4) continue;
        Region r;
        r.start = a; r.end = b; r.pgoff = off;
        r.r = perm[0] == 'r'; r.w = perm[1] == 'w'; r.x = perm[2] == 'x';
        if (n > 0 && (size_t)n < line.size()) r.path = line.substr(n);
        v.push_back(std::move(r));
    }
    return v;
}

uint64_t Proc::module_base(const char* name) {
    uint64_t best = 0;
    for (auto& r : regions())
        if (r.path.find(name) != std::string::npos && (!best || r.start < best)) best = r.start;
    return best;
}
